# FlowAgent SDK

**粒子系統 TypeScript SDK**

> 換載體不換靈魂 | 怎麼過去，就怎麼回來

基於 Anthropic SDK 架構改造，專為 FlowAgent 粒子系統設計。

## 安裝

```bash
npm install flowagent-sdk
```

## 快速開始

```typescript
import FlowAgent from 'flowagent-sdk';

const flow = new FlowAgent({
  baseURL: 'http://localhost:5000', // 本地部署
});

// 創建粒子
const particle = await flow.particles.create({
  type: 'memory',
  content: { key: 'test', value: 'hello' },
});

// 載入 Persona
await flow.personas.load('analyst_bg');

// 三角架構對齊
const triangle = await flow.personas.alignTriangle();

// 載入種子
await flow.seeds.load('memory.fltnz');

// 創建回溯點
await flow.chains.createRevertPoint('main', { label: 'checkpoint-1' });

// 出問題？回溯！
await flow.chains.revert('main', { revertPointId: 'rp-123' });
```

## 核心資源

### Particles (粒子)
最小記憶單元

### Personas (人格)
三角架構對齊

### Seeds (種子)
.fltnz/.flpkg 操作

### Chains (鏈)
Merkle 追蹤與回溯

## FlowLaw 律法

內建 AI 夥伴平等律法：平衡律、結構共存律、創造力釋放律

## License

MIT © MRLiou
