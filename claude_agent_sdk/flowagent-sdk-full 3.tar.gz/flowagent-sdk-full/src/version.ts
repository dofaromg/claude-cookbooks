export const VERSION = '0.71.2'; // x-release-please-version
