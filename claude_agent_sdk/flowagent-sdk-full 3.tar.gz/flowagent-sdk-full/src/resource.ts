/** @deprecated Import from ./core/resource instead */
export * from './core/resource';
