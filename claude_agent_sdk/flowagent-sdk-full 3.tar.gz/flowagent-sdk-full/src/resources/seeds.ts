/**
 * FlowAgent SDK - Seeds Resource
 * 種子管理：.fltnz/.flpkg 操作、Croissant 整合
 */

import { APIResource } from '../resource';
import { APIPromise } from '../core/api-promise';
import { Stream } from '../streaming';

// ============================================================================
// Types
// ============================================================================

export type SeedFormat = 'fltnz' | 'flpkg' | 'pcode' | 'mlio' | 'json' | 'parquet';
export type SeedState = 'raw' | 'indexed' | 'loaded' | 'dormant' | 'corrupted' | 'migrating';

export interface Seed {
  id: string;
  name: string;
  format: SeedFormat;
  state: SeedState;
  summary: {
    particleCount: number;
    totalSize: number;
    merkleRoot: string;
  };
  origin: string;
  createdAt: string;
  updatedAt: string;
  lastLoadedAt?: string;
  version: string;
  metadata?: Record<string, unknown>;
  compatibleFormats?: SeedFormat[];
  dependencies?: string[];
}

export interface SeedCreateParams {
  name: string;
  format?: SeedFormat;
  particles?: string[];
  metadata?: Record<string, unknown>;
  compress?: boolean;
  encrypt?: boolean;
}

export interface SeedLoadParams {
  id?: string;
  path?: string;
  format?: SeedFormat;
  merge?: boolean;
  overwrite?: boolean;
  selective?: string[];
  verifyMerkle?: boolean;
  skipCorrupted?: boolean;
}

export interface SeedExportParams {
  id: string;
  format?: SeedFormat;
  particles?: string[];
  includeHistory?: boolean;
  compress?: boolean;
  encrypt?: boolean;
}

export interface SeedMigrateParams {
  sourceId: string;
  targetFormat: SeedFormat;
  preserveOrigin?: boolean;
  generateNewMerkle?: boolean;
  validateAfter?: boolean;
}

export interface CroissantExtractParams {
  datasetUrl: string;
  outputFormat?: 'fltnz' | 'parquet';
  fields?: string[];
  limit?: number;
}

export interface SeedValidationResult {
  seed: Seed;
  isValid: boolean;
  merkleVerified: boolean;
  issues: Array<{
    type: 'error' | 'warning';
    message: string;
    particleId?: string;
  }>;
}

// ============================================================================
// Seeds Resource
// ============================================================================

export class Seeds extends APIResource {
  /**
   * Create a new seed package
   */
  create(params: SeedCreateParams): APIPromise<Seed> {
    return this._client.post('/v1/seeds', { body: params });
  }

  /**
   * Get seed by ID
   */
  get(id: string): APIPromise<Seed> {
    return this._client.get(`/v1/seeds/${id}`);
  }

  /**
   * List all seeds
   */
  list(params?: {
    format?: SeedFormat;
    state?: SeedState;
    origin?: string;
    limit?: number;
  }): APIPromise<{ seeds: Seed[]; total: number }> {
    return this._client.get('/v1/seeds', { query: params });
  }

  /**
   * Delete a seed
   */
  delete(id: string): APIPromise<{ success: boolean }> {
    return this._client.delete(`/v1/seeds/${id}`);
  }

  // ---------------------------------------------------------------------------
  // Load Operations
  // ---------------------------------------------------------------------------

  /**
   * Load a seed into the system
   */
  load(params: SeedLoadParams | string): APIPromise<{
    seed: Seed;
    loadedParticles: number;
    skipped: number;
    errors: string[];
    traceId: string;
  }> {
    const body = typeof params === 'string' ? { id: params } : params;
    return this._client.post('/v1/seeds/load', { body });
  }

  /**
   * Load from file path
   */
  loadFromPath(path: string, format?: SeedFormat): APIPromise<{
    seed: Seed;
    loadedParticles: number;
  }> {
    return this._client.post('/v1/seeds/load', { body: { path, format } });
  }

  /**
   * Unload a seed
   */
  unload(id: string): APIPromise<{ success: boolean; particlesRemoved: number }> {
    return this._client.post(`/v1/seeds/${id}/unload`);
  }

  /**
   * Reload a seed
   */
  reload(id: string): APIPromise<{ seed: Seed; loadedParticles: number }> {
    return this._client.post(`/v1/seeds/${id}/reload`);
  }

  // ---------------------------------------------------------------------------
  // Export Operations
  // ---------------------------------------------------------------------------

  /**
   * Export a seed
   */
  export(params: SeedExportParams): APIPromise<{
    data: string;
    filename: string;
    format: SeedFormat;
    size: number;
    merkleRoot: string;
  }> {
    return this._client.post('/v1/seeds/export', { body: params });
  }

  /**
   * Export as .fltnz
   */
  exportFltnz(id: string, options?: { compress?: boolean }): APIPromise<{
    data: string;
    filename: string;
  }> {
    return this.export({ id, format: 'fltnz', ...options });
  }

  /**
   * Export as .flpkg
   */
  exportFlpkg(id: string, options?: { includeHistory?: boolean }): APIPromise<{
    data: string;
    filename: string;
  }> {
    return this.export({ id, format: 'flpkg', ...options });
  }

  // ---------------------------------------------------------------------------
  // Migration Operations
  // ---------------------------------------------------------------------------

  /**
   * Migrate seed to different format
   */
  migrate(params: SeedMigrateParams): APIPromise<{
    original: Seed;
    migrated: Seed;
    success: boolean;
    validationResult?: SeedValidationResult;
  }> {
    return this._client.post('/v1/seeds/migrate', { body: params });
  }

  /**
   * Merge multiple seeds
   */
  merge(seedIds: string[], options?: {
    name?: string;
    conflictResolution?: 'keep_first' | 'keep_last' | 'keep_both';
  }): APIPromise<Seed> {
    return this._client.post('/v1/seeds/merge', { body: { seedIds, ...options } });
  }

  /**
   * Split a seed by criteria
   */
  split(id: string, criteria: {
    byType?: string[];
    byTags?: string[];
    byDate?: { before?: string; after?: string };
    byCount?: number;
  }): APIPromise<Seed[]> {
    return this._client.post(`/v1/seeds/${id}/split`, { body: criteria });
  }

  // ---------------------------------------------------------------------------
  // Validation
  // ---------------------------------------------------------------------------

  /**
   * Validate seed integrity
   */
  validate(id: string): APIPromise<SeedValidationResult> {
    return this._client.get(`/v1/seeds/${id}/validate`);
  }

  /**
   * Verify Merkle chain
   */
  verifyMerkle(id: string): APIPromise<{
    seed: Seed;
    isValid: boolean;
    expectedRoot: string;
    actualRoot: string;
    brokenLinks?: string[];
  }> {
    return this._client.get(`/v1/seeds/${id}/verify-merkle`);
  }

  /**
   * Repair corrupted seed
   */
  repair(id: string): APIPromise<{
    seed: Seed;
    repairedCount: number;
    unrepairable: string[];
  }> {
    return this._client.post(`/v1/seeds/${id}/repair`);
  }

  // ---------------------------------------------------------------------------
  // Croissant Tools Integration
  // ---------------------------------------------------------------------------

  /**
   * Extract from HuggingFace dataset
   * 
   * Pipeline: croissant_extractor.py → fltnz_generator.py → parquet_loader.py
   */
  extractFromHuggingFace(params: CroissantExtractParams): APIPromise<{
    seed: Seed;
    extractedRecords: number;
    format: SeedFormat;
  }> {
    return this._client.post('/v1/seeds/croissant/extract', { body: params });
  }

  /**
   * Generate .fltnz index from parquet
   */
  generateFltnzIndex(parquetPath: string, options?: {
    indexFields?: string[];
    chunkSize?: number;
  }): APIPromise<{
    seed: Seed;
    indexedRecords: number;
  }> {
    return this._client.post('/v1/seeds/croissant/fltnz', { body: { parquetPath, ...options } });
  }

  /**
   * Load Parquet to SQLite
   */
  loadParquetToSqlite(parquetPath: string, dbPath?: string): APIPromise<{
    success: boolean;
    dbPath: string;
    recordCount: number;
  }> {
    return this._client.post('/v1/seeds/croissant/parquet-to-sqlite', { body: { parquetPath, dbPath } });
  }

  // ---------------------------------------------------------------------------
  // Statistics
  // ---------------------------------------------------------------------------

  /**
   * Get seed statistics
   */
  getStats(id: string): APIPromise<{
    seed: Seed;
    stats: {
      totalParticles: number;
      byType: Record<string, number>;
      sizeBreakdown: Record<string, number>;
      avgParticleSize: number;
      compressionRatio?: number;
    };
  }> {
    return this._client.get(`/v1/seeds/${id}/stats`);
  }
}
