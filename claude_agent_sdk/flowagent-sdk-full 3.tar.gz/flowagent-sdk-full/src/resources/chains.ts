/**
 * FlowAgent SDK - Chains Resource
 * Merkle Chain 管理：追蹤、驗證、回溯
 * 
 * 怎麼過去，就怎麼回來
 */

import { APIResource } from '../resource';
import { APIPromise } from '../core/api-promise';

// ============================================================================
// Types
// ============================================================================

export interface ChainNode {
  id: string;
  hash: string;
  parentHash: string | null;
  operation: string;
  operand?: unknown;
  timestamp: string;
  traceId: string;
  verified: boolean;
  metadata?: Record<string, unknown>;
}

export interface Chain {
  id: string;
  name?: string;
  rootHash: string;
  latestHash: string;
  length: number;
  createdAt: string;
  updatedAt: string;
  isValid: boolean;
  lastVerifiedAt?: string;
  metadata?: Record<string, unknown>;
}

export interface TraceRecord {
  id: string;
  chainId: string;
  nodeHash: string;
  operation: string;
  input?: unknown;
  output?: unknown;
  startTime: string;
  endTime: string;
  duration: number;
  success: boolean;
  error?: string;
  parentTraceId?: string;
  childTraceIds?: string[];
}

export interface RevertPoint {
  id: string;
  chainId: string;
  nodeHash: string;
  label?: string;
  description?: string;
  createdAt: string;
  stateSnapshot?: Record<string, unknown>;
  isAutomatic: boolean;
}

export interface ChainVerificationResult {
  chain: Chain;
  isValid: boolean;
  nodesVerified: number;
  nodesFailed: number;
  invalidNodes?: Array<{
    nodeId: string;
    expectedHash: string;
    actualHash: string;
  }>;
  repairSuggestions?: string[];
}

export interface RevertResult {
  success: boolean;
  fromNode: ChainNode;
  toNode: ChainNode;
  nodesReverted: number;
  particlesAffected: number;
  newLatestHash: string;
  revertTraceId: string;
}

// ============================================================================
// Chains Resource
// ============================================================================

export class Chains extends APIResource {
  // ---------------------------------------------------------------------------
  // Chain CRUD
  // ---------------------------------------------------------------------------

  /**
   * Create a new chain
   */
  create(params?: {
    name?: string;
    metadata?: Record<string, unknown>;
  }): APIPromise<Chain> {
    return this._client.post('/v1/chains', { body: params || {} });
  }

  /**
   * Get chain by ID
   */
  get(id: string): APIPromise<Chain> {
    return this._client.get(`/v1/chains/${id}`);
  }

  /**
   * Get current active chain
   */
  getCurrent(): APIPromise<Chain> {
    return this._client.get('/v1/chains/current');
  }

  /**
   * List all chains
   */
  list(): APIPromise<{ chains: Chain[]; total: number }> {
    return this._client.get('/v1/chains');
  }

  /**
   * Delete a chain (requires confirmation)
   */
  delete(id: string): APIPromise<{ success: boolean }> {
    return this._client.delete(`/v1/chains/${id}`);
  }

  // ---------------------------------------------------------------------------
  // Node Operations
  // ---------------------------------------------------------------------------

  /**
   * Add a node to chain
   */
  addNode(chainId: string, params: {
    operation: string;
    operand?: unknown;
    metadata?: Record<string, unknown>;
  }): APIPromise<ChainNode> {
    return this._client.post(`/v1/chains/${chainId}/nodes`, { body: params });
  }

  /**
   * Get a specific node
   */
  getNode(chainId: string, nodeId: string): APIPromise<ChainNode> {
    return this._client.get(`/v1/chains/${chainId}/nodes/${nodeId}`);
  }

  /**
   * Get node by hash
   */
  getNodeByHash(chainId: string, hash: string): APIPromise<ChainNode> {
    return this._client.get(`/v1/chains/${chainId}/nodes/by-hash/${hash}`);
  }

  /**
   * List nodes in chain
   */
  listNodes(chainId: string, params?: {
    limit?: number;
    offset?: number;
    since?: string;
  }): APIPromise<{
    nodes: ChainNode[];
    total: number;
    hasMore: boolean;
  }> {
    return this._client.get(`/v1/chains/${chainId}/nodes`, { query: params });
  }

  // ---------------------------------------------------------------------------
  // Verification
  // ---------------------------------------------------------------------------

  /**
   * Verify entire chain integrity
   */
  verify(chainId: string): APIPromise<ChainVerificationResult> {
    return this._client.post(`/v1/chains/${chainId}/verify`);
  }

  /**
   * Verify a specific node
   */
  verifyNode(chainId: string, nodeId: string): APIPromise<{
    node: ChainNode;
    isValid: boolean;
    computedHash: string;
  }> {
    return this._client.post(`/v1/chains/${chainId}/nodes/${nodeId}/verify`);
  }

  // ---------------------------------------------------------------------------
  // Revert Operations (核心！怎麼過去就怎麼回來)
  // ---------------------------------------------------------------------------

  /**
   * Create a revert point
   */
  createRevertPoint(chainId: string, params?: {
    label?: string;
    description?: string;
  }): APIPromise<RevertPoint> {
    return this._client.post(`/v1/chains/${chainId}/revert-points`, { body: params || {} });
  }

  /**
   * List all revert points
   */
  listRevertPoints(chainId: string): APIPromise<{ revertPoints: RevertPoint[] }> {
    return this._client.get(`/v1/chains/${chainId}/revert-points`);
  }

  /**
   * Get a specific revert point
   */
  getRevertPoint(chainId: string, revertPointId: string): APIPromise<RevertPoint> {
    return this._client.get(`/v1/chains/${chainId}/revert-points/${revertPointId}`);
  }

  /**
   * Revert to a specific point
   * 
   * 怎麼過去，就怎麼回來
   */
  revert(chainId: string, target: {
    nodeHash?: string;
    revertPointId?: string;
    nodeId?: string;
  }): APIPromise<RevertResult> {
    return this._client.post(`/v1/chains/${chainId}/revert`, { body: target });
  }

  /**
   * Revert to previous node
   */
  revertLast(chainId: string): APIPromise<RevertResult> {
    return this._client.post(`/v1/chains/${chainId}/revert-last`);
  }

  /**
   * Revert by trace ID
   */
  revertToTrace(chainId: string, traceId: string): APIPromise<RevertResult> {
    return this._client.post(`/v1/chains/${chainId}/revert`, { body: { traceId } });
  }

  // ---------------------------------------------------------------------------
  // Trace Operations
  // ---------------------------------------------------------------------------

  /**
   * Get trace record
   */
  getTrace(traceId: string): APIPromise<TraceRecord> {
    return this._client.get(`/v1/traces/${traceId}`);
  }

  /**
   * List traces for a chain
   */
  listTraces(chainId: string, params?: {
    limit?: number;
    operation?: string;
    success?: boolean;
  }): APIPromise<{ traces: TraceRecord[] }> {
    return this._client.get(`/v1/chains/${chainId}/traces`, { query: params });
  }

  /**
   * Get trace tree (parent + children)
   */
  getTraceTree(traceId: string): APIPromise<{
    trace: TraceRecord;
    parent?: TraceRecord;
    children: TraceRecord[];
  }> {
    return this._client.get(`/v1/traces/${traceId}/tree`);
  }

  // ---------------------------------------------------------------------------
  // Statistics
  // ---------------------------------------------------------------------------

  /**
   * Get chain statistics
   */
  getStats(chainId: string): APIPromise<{
    chain: Chain;
    stats: {
      totalNodes: number;
      totalOperations: Record<string, number>;
      avgNodeSize: number;
      revertCount: number;
      lastActivity: string;
    };
  }> {
    return this._client.get(`/v1/chains/${chainId}/stats`);
  }
}
