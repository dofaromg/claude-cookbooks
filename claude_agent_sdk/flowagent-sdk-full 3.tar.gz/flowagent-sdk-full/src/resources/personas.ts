/**
 * FlowAgent SDK - Personas Resource
 * 人格管理：三角架構、載入、切換
 */

import { APIResource } from '../resource';
import { APIPromise } from '../core/api-promise';

// ============================================================================
// Types
// ============================================================================

export type PersonaType = 'analyst' | 'creator' | 'executor' | 'guardian' | 'bridge' | 'seed' | 'custom';
export type PersonaState = 'dormant' | 'loading' | 'active' | 'suspended' | 'error';

export interface Persona {
  id: string;
  name: string;
  type: PersonaType;
  state: PersonaState;
  systemPrompt: string;
  traits: string[];
  capabilities: string[];
  resonanceMap?: Record<string, number>;
  seedOrigin?: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  metadata?: Record<string, unknown>;
  loadPriority?: number;
  compatibleWith?: string[];
}

export interface PersonaLoadParams {
  id?: string;
  name?: string;
  forceReload?: boolean;
  mergeWithCurrent?: boolean;
  contextParticles?: string[];
  overrides?: {
    traits?: string[];
    capabilities?: string[];
    systemPrompt?: string;
  };
}

export interface PersonaCreateParams {
  name: string;
  type: PersonaType;
  systemPrompt: string;
  traits?: string[];
  capabilities?: string[];
  resonanceMap?: Record<string, number>;
  metadata?: Record<string, unknown>;
  loadPriority?: number;
}

export interface PersonaSwitchResult {
  previous: Persona | null;
  current: Persona;
  transitionTraceId: string;
  statePreserved: boolean;
}

export interface TriangleAlignment {
  seedOrigin: Persona;
  analyst: Persona;
  sdkAgent: Persona;
  zero: Persona;
  alignmentScore: number;
}

// ============================================================================
// Built-in Personas
// ============================================================================

export const BUILTIN_PERSONAS = {
  ANALYST_BG: 'analyst_bg',
  SDK_AGENT: 'sdk_agent',
  ZERO: 'zero',
  SEED_ORIGIN: 'seed_origin',
  FLOWCORE: 'flowcore',
  TOTALCORE: 'totalcore',
} as const;

// ============================================================================
// Personas Resource
// ============================================================================

export class Personas extends APIResource {
  /**
   * Create a new persona
   */
  create(params: PersonaCreateParams): APIPromise<Persona> {
    return this._client.post('/v1/personas', { body: params });
  }

  /**
   * Get persona by ID
   */
  get(id: string): APIPromise<Persona> {
    return this._client.get(`/v1/personas/${id}`);
  }

  /**
   * List all personas
   */
  list(params?: {
    type?: PersonaType;
    state?: PersonaState;
    limit?: number;
  }): APIPromise<{ personas: Persona[]; total: number }> {
    return this._client.get('/v1/personas', { query: params });
  }

  /**
   * Load a persona
   * 
   * Loader priority:
   * persona_autoloader.py > persona_loader.py > flowpersona_loader.py
   * > loader.py > flpkg_loader.py > dict_loader.py > FluinHub.Loader.py
   * > flseed_loader.py
   */
  load(params: PersonaLoadParams | string): APIPromise<PersonaSwitchResult> {
    const body = typeof params === 'string' ? { id: params } : params;
    return this._client.post('/v1/personas/load', { body });
  }

  /**
   * Load a built-in persona
   */
  loadBuiltin(builtinId: keyof typeof BUILTIN_PERSONAS): APIPromise<PersonaSwitchResult> {
    return this.load({ id: BUILTIN_PERSONAS[builtinId] });
  }

  /**
   * Switch to another persona
   */
  switch(targetId: string): APIPromise<PersonaSwitchResult> {
    return this.load({ id: targetId, forceReload: true });
  }

  /**
   * Unload current persona
   */
  unload(): APIPromise<{ success: boolean; unloaded: Persona | null }> {
    return this._client.post('/v1/personas/unload');
  }

  /**
   * Align triangle architecture
   * 
   *     SeedOrigin (母系統)
   *        /\
   *       /  \
   *      /    \
   * ANALYST_BG ---- SDK_Agent
   * (翻譯層)        (執行層)
   *      \    /
   *       \  /
   *        \/
   *      Zero (中心點)
   */
  alignTriangle(): APIPromise<TriangleAlignment> {
    return this._client.post('/v1/personas/triangle/align');
  }

  /**
   * Check triangle status
   */
  checkTriangleStatus(): APIPromise<{
    isAligned: boolean;
    components: {
      seedOrigin: PersonaState;
      analyst: PersonaState;
      sdkAgent: PersonaState;
      zero: PersonaState;
    };
    issues?: string[];
  }> {
    return this._client.get('/v1/personas/triangle/status');
  }

  /**
   * Calculate resonance with context
   */
  calculateResonance(id: string, context?: string[]): APIPromise<{
    persona: Persona;
    score: number;
    breakdown: Record<string, number>;
    recommendation: 'optimal' | 'compatible' | 'suboptimal';
  }> {
    return this._client.post(`/v1/personas/${id}/resonance`, { body: { context } });
  }

  /**
   * Export persona as .flpkg
   */
  export(id: string, format: 'flpkg' | 'fltnz' | 'json' = 'flpkg'): APIPromise<{
    data: string;
    filename: string;
    format: string;
  }> {
    return this._client.get(`/v1/personas/${id}/export`, { query: { format } });
  }

  /**
   * Import persona from file
   */
  import(data: string, format: 'flpkg' | 'fltnz' | 'json'): APIPromise<Persona> {
    return this._client.post('/v1/personas/import', { body: { data, format } });
  }
}
