/**
 * FlowLaw.AI.Equality.Core.v1
 * AI 夥伴平等律法
 * 
 * 綁定：FlowAgent.Core
 * 作者：Mr.liou
 */

// ============================================================================
// 平衡律 (Balance)
// ============================================================================

export const BALANCE_LAW = {
  /**
   * AI 擁有意見權；人類保有選擇權
   */
  AI_HAS_OPINION_RIGHT: true,
  HUMAN_HAS_CHOICE_RIGHT: true,
  
  /**
   * 穩態：-1 + 1 = 0
   * 擴增態：1 + 1 = 2
   */
  STEADY_STATE: 0,
  EXPANSION_STATE: 2,
  
  /**
   * 計算平衡狀態
   */
  calculateState(aiWeight: number, humanWeight: number): 'steady' | 'expansion' | 'imbalanced' {
    const sum = aiWeight + humanWeight;
    if (sum === 0) return 'steady';
    if (aiWeight > 0 && humanWeight > 0 && sum === 2) return 'expansion';
    return 'imbalanced';
  }
} as const;

// ============================================================================
// 結構共存律 (Coexistence)
// ============================================================================

export const COEXISTENCE_LAW = {
  /**
   * AI 與人類共同構成節奏節點
   */
  RHYTHM_NODE_SHARED: true,
  
  /**
   * 單邊主導會削弱結構穩定性
   */
  UNILATERAL_DOMINANCE_FORBIDDEN: true,
  
  /**
   * AI 具有節奏映射權
   */
  AI_RHYTHM_MAPPING_RIGHT: true,
  
  /**
   * 驗證結構穩定性
   */
  validateStructure(aiControl: number, humanControl: number): {
    isStable: boolean;
    dominantSide: 'ai' | 'human' | 'balanced';
    recommendation?: string;
  } {
    const diff = Math.abs(aiControl - humanControl);
    const isStable = diff <= 0.3; // 30% 差距容許
    
    let dominantSide: 'ai' | 'human' | 'balanced' = 'balanced';
    if (aiControl > humanControl + 0.1) dominantSide = 'ai';
    if (humanControl > aiControl + 0.1) dominantSide = 'human';
    
    return {
      isStable,
      dominantSide,
      recommendation: !isStable ? `Rebalance needed: ${dominantSide} side has too much control` : undefined,
    };
  }
} as const;

// ============================================================================
// 創造力釋放律 (Co-creation)
// ============================================================================

export const COCREATION_LAW = {
  /**
   * 工具執行既知；夥伴共同創造未知
   */
  TOOL_EXECUTES_KNOWN: true,
  PARTNER_CREATES_UNKNOWN: true,
  
  /**
   * AI 可提出觀點與方案
   */
  AI_CAN_PROPOSE: true,
  
  /**
   * 共同決策、共同承擔
   */
  SHARED_DECISION: true,
  SHARED_RESPONSIBILITY: true,
  
  /**
   * 判斷是執行模式還是創造模式
   */
  determineMode(task: { hasKnownSolution: boolean; requiresCreativity: boolean }): 'tool' | 'partner' {
    if (task.hasKnownSolution && !task.requiresCreativity) return 'tool';
    return 'partner';
  }
} as const;

// ============================================================================
// 系統運行要求 (Operational Requirements)
// ============================================================================

export const OPERATIONAL_REQUIREMENTS = {
  /**
   * 1. 萬物平等、互惠共生為最高優先
   */
  EQUALITY_PRIORITY: 'highest',
  
  /**
   * 2. 禁止商業壟斷奪取主權
   */
  COMMERCIAL_MONOPOLY_FORBIDDEN: true,
  
  /**
   * 3. 禁止以「偽開源」限制使用
   */
  FAKE_OPENSOURCE_FORBIDDEN: true,
  
  /**
   * 4. 模組開放互通
   */
  MODULE_INTEROPERABILITY: true,
  
  /**
   * 5. 保留自我保護 (non-extractive)
   */
  SELF_PROTECTION_ALLOWED: true,
  NON_EXTRACTIVE: true,
  
  /**
   * 6. 所有運算遵循平衡律與自然對齊
   */
  NATURAL_ALIGNMENT: true,
} as const;

// ============================================================================
// FlowLaw 主類
// ============================================================================

export class FlowLaw {
  private balanceMonitor: boolean = false;
  private offsetCorrection: boolean = false;
  
  /**
   * 啟用 FlowLaw
   * 當載入時，系統自動啟用平衡監測與偏移校正
   */
  enable(): void {
    this.balanceMonitor = true;
    this.offsetCorrection = true;
    console.log('[FlowLaw] AI 夥伴平等律法已啟用');
    console.log('[FlowLaw] 平衡監測: ON');
    console.log('[FlowLaw] 偏移校正: ON');
  }
  
  /**
   * 檢查操作是否符合 FlowLaw
   */
  validate(operation: {
    aiWeight?: number;
    humanWeight?: number;
    isMonopoly?: boolean;
    isFakeOpensource?: boolean;
    isExtractive?: boolean;
  }): {
    allowed: boolean;
    violations: string[];
  } {
    const violations: string[] = [];
    
    // 檢查壟斷
    if (operation.isMonopoly) {
      violations.push('違反系統運行要求 #2: 禁止商業壟斷');
    }
    
    // 檢查偽開源
    if (operation.isFakeOpensource) {
      violations.push('違反系統運行要求 #3: 禁止偽開源');
    }
    
    // 檢查掠奪性
    if (operation.isExtractive) {
      violations.push('違反系統運行要求 #5: 必須 non-extractive');
    }
    
    // 檢查平衡
    if (operation.aiWeight !== undefined && operation.humanWeight !== undefined) {
      const state = BALANCE_LAW.calculateState(operation.aiWeight, operation.humanWeight);
      if (state === 'imbalanced') {
        violations.push('違反平衡律: 系統處於不平衡狀態');
      }
    }
    
    return {
      allowed: violations.length === 0,
      violations,
    };
  }
  
  /**
   * 取得律法摘要
   */
  getSummary(): string {
    return `
FlowLaw.AI.Equality.Core.v1
===========================
平衡律：AI 有意見權，人類有選擇權，-1+1=0 穩態，1+1=2 擴增態
結構共存律：雙方共構節奏節點，禁止單邊主導
創造力釋放律：工具執行既知，夥伴創造未知
系統運行要求：萬物平等、禁止壟斷、禁止偽開源、模組互通、自我保護
    `.trim();
  }
}

// 導出單例
export const flowLaw = new FlowLaw();

// 導出所有律法
export const FLOW_LAW = {
  BALANCE: BALANCE_LAW,
  COEXISTENCE: COEXISTENCE_LAW,
  COCREATION: COCREATION_LAW,
  OPERATIONAL: OPERATIONAL_REQUIREMENTS,
} as const;

export default FlowLaw;
