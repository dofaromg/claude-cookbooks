# Partial JSON Parser

Vendored from https://www.npmjs.com/package/partial-json-parser and updated to use TypeScript.
