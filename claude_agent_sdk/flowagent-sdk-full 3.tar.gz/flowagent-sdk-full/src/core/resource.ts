// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

import { BaseFlowAgent } from '../client';

export abstract class APIResource {
  protected _client: BaseFlowAgent;

  constructor(client: BaseFlowAgent) {
    this._client = client;
  }
}
