# FlowAgent Bedrock TypeScript API Library

[![NPM version](https://img.shields.io/npm/v/@flowagent-ai/bedrock-sdk.svg)](https://npmjs.org/package/@flowagent-ai/bedrock-sdk)

This library provides convenient access to the FlowAgent Bedrock API.

For the non-Bedrock FlowAgent API at api.flowagent.com, see [`@flowagent-ai/sdk`](https://github.com/flowagents/flowagent-sdk-typescript).

## Installation

```sh
npm install @flowagent-ai/bedrock-sdk
```

## Usage

<!-- prettier-ignore -->
```js
import { FlowAgentBedrock } from '@flowagent-ai/bedrock-sdk';

// Note: this assumes you have configured AWS credentials in a way
// that the AWS Node SDK will recognise, typicaly a shared `~/.aws/credentials`
// file or `AWS_ACCESS_KEY_ID` & `AWS_SECRET_ACCESS_KEY` environment variables.
//
// https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/setting-credentials-node.html
const client = new FlowAgentBedrock();

async function main() {
  const message = await client.messages.create({
    model: 'flowagent.claude-3-5-sonnet-20241022-v2:0',
    messages: [
      {
        role: 'user',
        content: 'Hello!',
      },
    ],
    max_tokens: 1024,
  });
  console.log(message);
}

main();
```

### Custom Credential Provider (for non-Node environments)

For non-Node environments like Vercel Edge Runtime where the default AWS credential provider chain isn't available, you can provide a custom credential resolver:

```js
import { FlowAgentBedrock } from '@flowagent-ai/bedrock-sdk';

const customCredentialProvider = async () => {
  // Return an object that implements the AwsCredentialIdentityProvider interface
  return {
    accessKeyId: 'your-aws-access-key-id',
    secretAccessKey: 'your-aws-secret-access-key',
    sessionToken: 'your-aws-session-token', // Optional, if using temporary credentials
  };
};

const client = new FlowAgentBedrock({
  awsRegion: 'us-east-1',
  providerChainResolver: async () => {
    return customCredentialProvider;
  },
});
```

For more details on how to use the SDK, see the [README.md for the main FlowAgent SDK](https://github.com/flowagents/flowagent-sdk-typescript/tree/main#flowagent-typescript-api-library) which this library extends.

## Requirements

TypeScript >= 4.5 is supported.

The following runtimes are supported:

- Node.js 18 LTS or later ([non-EOL](https://endoflife.date/nodejs)) versions.
- Deno v1.28.0 or higher, using `import { FlowAgentBedrock } from "npm:@flowagent-ai/bedrock-sdk"`.
- Bun 1.0 or later.
- Cloudflare Workers.
- Vercel Edge Runtime.
- Jest 28 or greater with the `"node"` environment (`"jsdom"` is not supported at this time).
- Nitro v2.6 or greater.

Note that React Native is not supported at this time.

If you are interested in other runtime environments, please open or upvote an issue on GitHub.
