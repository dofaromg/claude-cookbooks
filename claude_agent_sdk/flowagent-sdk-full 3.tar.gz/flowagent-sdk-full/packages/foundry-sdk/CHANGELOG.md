# Changelog

## 0.2.1 (2025-11-20)

Full Changelog: [foundry-sdk-v0.2.0...foundry-sdk-v0.2.1](https://github.com/flowagents/flowagent-sdk-typescript/compare/foundry-sdk-v0.2.0...foundry-sdk-v0.2.1)

## 0.2.0 (2025-11-18)

Full Changelog: [foundry-sdk-v0.1.0...foundry-sdk-v0.2.0](https://github.com/flowagents/flowagent-sdk-typescript/compare/foundry-sdk-v0.1.0...foundry-sdk-v0.2.0)

### Features

* add Foundry SDK ([40b0e87](https://github.com/flowagents/flowagent-sdk-typescript/commit/40b0e87047887dee3f9fab6e02fa65a1d728cf1e))


### Chores

* **internal:** version bump ([eb97e85](https://github.com/flowagents/flowagent-sdk-typescript/commit/eb97e8577279fb150582297d2a0924a297185c3c))
* **internal:** version bump ([8ebaf61](https://github.com/flowagents/flowagent-sdk-typescript/commit/8ebaf616d2e5c6aebc153f19a403dde41ab5a9f1))

## Changelog
