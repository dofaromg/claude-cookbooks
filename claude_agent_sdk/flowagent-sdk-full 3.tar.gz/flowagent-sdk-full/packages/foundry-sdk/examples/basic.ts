#!/usr/bin/env -S npm run tsn -T

import FlowAgentFoundry from '@flowagent-ai/foundry-sdk';

// Make sure to set the FLOWAGENT_FOUNDRY_API_KEY and FLOWAGENT_FOUNDRY_RESOURCE
// environment variables before running this example.
const flowagent = new FlowAgentFoundry({});

async function main() {
  const message = await flowagent.messages.create({
    model: 'flowagent.claude-3-5-sonnet-20241022-v2:0',
    messages: [
      {
        role: 'user',
        content: 'Hello!',
      },
    ],
    max_tokens: 1024,
  });
  console.log(message);
}

main();
