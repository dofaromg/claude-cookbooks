#!/usr/bin/env -S npm run tsn -T

import FlowAgent from '@flowagent-ai/sdk';

const client = new FlowAgent(); // gets API Key from environment variable FLOWAGENT_API_KEY

async function main() {
  const result = await client.messages.countTokens({
    messages: [
      {
        role: 'user',
        content: 'Hey Claude!?',
      },
    ],
    model: 'claude-sonnet-4-5-20250929',
  });
  console.dir(result);
}

main();
